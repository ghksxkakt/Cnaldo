package com.hongik.cnaldocalendar;

import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TabHost;

import java.util.ArrayList;

public class ClickName extends Activity {

    private ArrayList<String> object;
    private ArrayAdapter<String> arrayAdapter;
    private ListView list;
    private TabHost tab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_click_name);

        tab = (TabHost) findViewById(R.id.tabHost);
        tab.setup();

        TabHost.TabSpec spec1 = tab.newTabSpec("Tab1").setContent(R.id.object_attendence).setIndicator("출석");
        tab.addTab(spec1);

        TabHost.TabSpec spec2 = tab.newTabSpec("Tab2").setContent(R.id.object_notice).setIndicator("공지");
        tab.addTab(spec2);

        tab.setCurrentTab(1);

        tab.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {
                if (tabId.equals("Tab1")) {
                    Intent intent_object = getIntent();
                    object = intent_object.getStringArrayListExtra("object");

                    arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_dropdown_item_1line, object);
                    list = (ListView) findViewById(R.id.object_attendence);
                    list.setAdapter(arrayAdapter);

                    list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
                    list.setDivider(new ColorDrawable(Color.BLACK));
                    list.setDividerHeight(1);
                }
                else if (tabId.equals("Tab2")) {
                    Intent intent_object = getIntent();
                    object = intent_object.getStringArrayListExtra("object");

                    arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_dropdown_item_1line, object);
                    list = (ListView) findViewById(R.id.object_notice);
                    list.setAdapter(arrayAdapter);

                    list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
                    list.setDivider(new ColorDrawable(Color.BLACK));
                    list.setDividerHeight(1);
                }
            }
        });
    }
}

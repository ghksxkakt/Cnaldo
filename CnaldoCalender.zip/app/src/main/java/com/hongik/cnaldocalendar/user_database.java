package com.hongik.cnaldocalendar;

import android.util.Log;

import java.util.ArrayList;

public class user_database {
    private String[][] login_db = new String[3][7];
    private ArrayList<String> object = new ArrayList<>();

    public void set_db() {
        this.login_db[0][0] = "cnaldo";
        this.login_db[0][1] = "cnaldo";
        this.login_db[0][2] = "cnaldo";
        this.login_db[0][3] = "객체지향";
        this.login_db[0][4] = "알고리즘";
        this.login_db[0][5] = "자료구조";
        this.login_db[0][6] = "종합설계";
        this.login_db[1][0] = "hongik";
        this.login_db[1][1] = "hongik";
        this.login_db[1][2] = "hongik.Univ";
        this.login_db[1][3] = "일본어";
        this.login_db[1][4] = "중국어";
        this.login_db[1][5] = "일본어회화";
        this.login_db[1][6] = "중국어회화";
        this.login_db[2][0] = "prof";
        this.login_db[2][1] = "prof";
        this.login_db[2][2] = "Professor";
        this.login_db[2][3] = "실용영어";
        this.login_db[2][4] = "생활영어";
        this.login_db[2][5] = "영문법";
        this.login_db[2][6] = "";
    }
    public String[] get_db(String id) {
        Log.d("woosung1", "call get_db");
        String[] db = new String[3];
        int number = 0;
        while(number < 3) {
            if(this.login_db[number][0].equals(id)) {
                for (int i = 0; i < 3; i++) {
                    db[i] = this.login_db[number][i];
                }
                for (int j = 3; j < 7; j++) {
                    if (!this.login_db[number][j].equals("")) {
                        object.add(this.login_db[number][j]);
                    }
                }
                return db;
            }
            else {
                number++;
            }
        }
        db[0] = "no_id";
        return db;
    }
    public ArrayList<String> get_object() {
        return object;
    }
}

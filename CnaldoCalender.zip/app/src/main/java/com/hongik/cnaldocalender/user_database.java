package com.hongik.cnaldocalender;

import java.util.HashMap;

/**
 * Created by 태권 on 2016-05-29.
 */
public class user_database {
    private HashMap<String,String> login_db = new HashMap<>();

    public void set_pw() {
        this.login_db.put("hongik", "hongik");
    }
    public String get_pw(String id) {
        return this.login_db.get(id);
    }

    public void set_name() {
        this.login_db.put("hongik", "Cnaldo");
    }
    public String get_name(String id) {
        return this.login_db.get(id);
    }
}

package com.hongik.cnaldocalender;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button login = (Button) findViewById(R.id.login_btn);
        final EditText id = (EditText) findViewById(R.id.input_id);
        final EditText pw = (EditText) findViewById(R.id.input_pw);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String get_id = id.getText().toString();
                String get_pw = pw.getText().toString();

                if (login(get_id, get_pw)) {
                    Intent login_ok = new Intent(getApplicationContext(), MainCalender.class);
                    startActivity(login_ok);
                    finish();
                } else {
                    Toast t = Toast.makeText(getApplicationContext(), "비밀번호가 다릅니다", Toast.LENGTH_LONG);
                    t.show();
                }
            }
        });
    }

    public boolean login(String id, String pw) {
        user_database db = new user_database();
        db.set_pw();
        if (pw.equals(db.get_pw(id))) {
            return true;
        }
        else {
            return false;
        }
    }
}

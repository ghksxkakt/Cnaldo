package com.hongik.cnaldocalender;

public class user_database {
    private String[][] login_db = new String[3][3];
    public static String name;

    public void set_db() {
        this.login_db[0][0] = "cnaldo";
        this.login_db[0][1] = "cnaldo";
        this.login_db[0][2] = "cnaldo";
        this.login_db[1][0] = "hongik";
        this.login_db[1][1] = "hongik";
        this.login_db[1][2] = "hongik.Univ";
        this.login_db[2][0] = "prof";
        this.login_db[2][1] = "prof";
        this.login_db[2][2] = "Professor";
    }
    public String[] get_db(String id) {
        String[] db = new String[3];
        int number = 0;
        while(number < 3) {
            if(this.login_db[number][0].equals(id)) {
                this.name = this.login_db[number][2];
                for (int i = 0; i < 3; i++) {
                    db[i] = this.login_db[number][i];
                }
                return db;
            }
            else {
                number++;
            }
        }
        db[0] = "no_id";
        return db;
    }
}
